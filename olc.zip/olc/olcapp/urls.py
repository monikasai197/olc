from django.contrib import admin
from django.urls import path
from .views import adminloginview,adminhomepageview,authenticateadmin,logoutadmin,allusers,homepageview,signupuser,userloginview,userwelcomeview,userauthenticate,userlogout

urlpatterns = [
    path('admin/',adminloginview,name = 'adminloginpage'),
    path('admin/homepage/',adminhomepageview,name = 'adminhomepage'),
    path('adminauthenticate/',authenticateadmin),
    path('adminlogout/',logoutadmin),
    path('allusers/',allusers),
    path('',homepageview,name = 'homepage'),
    path('signupuser/',signupuser),
    path('loginuser/',userloginview,name = 'userloginpage'),
    path('user/welcome/',userwelcomeview,name = 'userpage'),
    path('user/authenticate/',userauthenticate),
    path('userlogout/',userlogout),
]