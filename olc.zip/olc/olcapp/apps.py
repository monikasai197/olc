from django.apps import AppConfig


class OlcappConfig(AppConfig):
    name = 'olcapp'
