from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from django.contrib.auth.models import User
from .models import UserModel

# Create your views here.

def adminloginview(request):
	return render(request,"olcapp/adminlogin.html")

def authenticateadmin(request):

	username = request.POST['username']
	password = request.POST['password']

	user = authenticate(username = username,password = password)

	# user exists
	if user is not None and user.username=="admin":
		login(request,user)
		return redirect('adminhomepage')

	# user doesn't exists
	if user is None:
		messages.add_message(request,messages.ERROR,"Invalid Credentials")
		return redirect('adminloginpage')

def adminhomepageview(request):
	return render(request,"olcapp/adminhomepage.html")

def logoutadmin(request):
	logout(request)
	return redirect('adminloginpage')

def allusers(request):
	users = UserModel.objects.all()
	context = {'users' : users}
	return render(request,'olcapp/allusers.html',context)

def homepageview(request):
	return render(request,"olcapp/homepage.html")

def signupuser(request):
	username = request.POST['username']
	password = request.POST['password']
	phoneno = request.POST['phoneno']
	
	# if username already exists
	if User.objects.filter(username = username).exists():
		messages.add_message(request,messages.ERROR,"User already exists.Please LOGIN")
		return redirect('homepage')

	# if username doesn't exists
	User.objects.create_user(username = username,password = password).save()
	lastobject = len(User.objects.all())-1
	UserModel(userid = User.objects.all()[int(lastobject)].id,phoneno = phoneno).save()
	messages.add_message(request,messages.ERROR,"User successfully added.Please LOGIN")
	return redirect('homepage')

def userloginview(request):
	return render(request,"olcapp/userlogin.html")

def userauthenticate(request):
	username = request.POST['username']
	password = request.POST['password']

	user = authenticate(username = username,password = password)

	# user exists
	if user is not None:
		login(request,user)
		return redirect('userpage')

	# user doesn't exist
	if user is None:
		messages.add_message(request,messages.ERROR,"Invalid Credentials")
		return redirect('userloginpage')

def userwelcomeview(request):
	if not request.user.is_authenticated:
		return redirect('userloginpage')

	username = request.user.username
	context = {'username' : username}
	return render(request,'olcapp/userwelcome.html',context)

def userlogout(request):
	logout(request)
	return redirect('userloginpage')